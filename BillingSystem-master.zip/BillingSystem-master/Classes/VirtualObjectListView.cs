﻿namespace BillingSystem
{
    internal class VirtualObjectListView
    {
    }
}