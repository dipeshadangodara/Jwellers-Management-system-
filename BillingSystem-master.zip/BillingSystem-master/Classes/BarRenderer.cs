﻿namespace BillingSystem
{
    internal class BarRenderer
    {
    }
}