﻿namespace BillingSystem
{
    internal class OLVListItem
    {
    }
}