﻿using System;
using System.Windows.Forms;

namespace BillingSystem
{
    internal class ObjectListView
    {
        public sbyte RowHeight { get; internal set; }

        public static explicit operator ObjectListView(ListView v)
        {
            throw new NotImplementedException();
        }
    }
}