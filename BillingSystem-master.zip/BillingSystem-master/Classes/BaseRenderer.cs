﻿namespace BillingSystem
{
    internal class BaseRenderer
    {
    }
}