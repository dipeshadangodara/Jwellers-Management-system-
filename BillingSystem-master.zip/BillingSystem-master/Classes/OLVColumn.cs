﻿using System;
using System.Windows.Forms;

namespace BillingSystem
{
    internal class OLVColumn
    {
        public object Renderer { get; internal set; }

        public static explicit operator OLVColumn(ColumnHeader v)
        {
            throw new NotImplementedException();
        }
    }
}