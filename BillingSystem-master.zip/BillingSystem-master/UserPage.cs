﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.OleDb;
namespace BillingSystem
{
    public partial class UserPage : Form
    {
        public UserPage()
        {
            InitializeComponent();
        }

        string cs = ConfigurationManager.ConnectionStrings["BillingSystem.Properties.Settings.BillingDBConnectionString"].ConnectionString;

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void UserPage_Load(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(cs);
            string query = "select *from LoginTbl";
            OleDbCommand cmd = new OleDbCommand(query, con);
            con.Open();
            OleDbDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                txtusername.Text = dr.GetString(1);
                txtpassword.Text = dr.GetString(2);
            }
            con.Close();
                   

    }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
