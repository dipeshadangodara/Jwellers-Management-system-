﻿namespace BillingSystem
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.buttonCreateInvoice = new System.Windows.Forms.Button();
            this.btnListItem = new System.Windows.Forms.Button();
            this.buttonAddCustomers = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbltime = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonCreateInvoice
            // 
            this.buttonCreateInvoice.BackColor = System.Drawing.Color.Transparent;
            this.buttonCreateInvoice.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.buttonCreateInvoice.FlatAppearance.BorderSize = 0;
            this.buttonCreateInvoice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonCreateInvoice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonCreateInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateInvoice.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.buttonCreateInvoice.Image = ((System.Drawing.Image)(resources.GetObject("buttonCreateInvoice.Image")));
            this.buttonCreateInvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCreateInvoice.Location = new System.Drawing.Point(0, 270);
            this.buttonCreateInvoice.Name = "buttonCreateInvoice";
            this.buttonCreateInvoice.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonCreateInvoice.Size = new System.Drawing.Size(216, 60);
            this.buttonCreateInvoice.TabIndex = 6;
            this.buttonCreateInvoice.Text = "          Create Invoices";
            this.buttonCreateInvoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCreateInvoice.UseVisualStyleBackColor = false;
            this.buttonCreateInvoice.Click += new System.EventHandler(this.buttonCreateInvoice_Click);
            // 
            // btnListItem
            // 
            this.btnListItem.BackColor = System.Drawing.Color.Transparent;
            this.btnListItem.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.btnListItem.FlatAppearance.BorderSize = 0;
            this.btnListItem.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.btnListItem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.btnListItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListItem.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.btnListItem.Image = ((System.Drawing.Image)(resources.GetObject("btnListItem.Image")));
            this.btnListItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListItem.Location = new System.Drawing.Point(0, 353);
            this.btnListItem.Name = "btnListItem";
            this.btnListItem.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnListItem.Size = new System.Drawing.Size(216, 60);
            this.btnListItem.TabIndex = 5;
            this.btnListItem.Text = "          List All Items";
            this.btnListItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnListItem.UseVisualStyleBackColor = false;
            this.btnListItem.Click += new System.EventHandler(this.buttonAddItems_Click);
            // 
            // buttonAddCustomers
            // 
            this.buttonAddCustomers.BackColor = System.Drawing.Color.Transparent;
            this.buttonAddCustomers.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.buttonAddCustomers.FlatAppearance.BorderSize = 0;
            this.buttonAddCustomers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonAddCustomers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonAddCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCustomers.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.buttonAddCustomers.Image = ((System.Drawing.Image)(resources.GetObject("buttonAddCustomers.Image")));
            this.buttonAddCustomers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCustomers.Location = new System.Drawing.Point(0, 112);
            this.buttonAddCustomers.Name = "buttonAddCustomers";
            this.buttonAddCustomers.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.buttonAddCustomers.Size = new System.Drawing.Size(216, 60);
            this.buttonAddCustomers.TabIndex = 4;
            this.buttonAddCustomers.Text = "           Add Customers";
            this.buttonAddCustomers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddCustomers.UseVisualStyleBackColor = false;
            this.buttonAddCustomers.Click += new System.EventHandler(this.buttonAddCustomers_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(3, 430);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(216, 60);
            this.button5.TabIndex = 17;
            this.button5.Text = "            Sold Items";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(2, 601);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(210, 42);
            this.button2.TabIndex = 13;
            this.button2.Text = "Logout";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Transparent;
            this.btnHome.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.btnHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 31);
            this.btnHome.Name = "btnHome";
            this.btnHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnHome.Size = new System.Drawing.Size(216, 60);
            this.btnHome.TabIndex = 16;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 190);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(216, 60);
            this.button1.TabIndex = 14;
            this.button1.Text = "       Customers list";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(1254, 44);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(56, 36);
            this.button4.TabIndex = 17;
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.OldLace;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(1315, 48);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(42, 33);
            this.button3.TabIndex = 16;
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Colonna MT", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(609, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(542, 35);
            this.label1.TabIndex = 15;
            this.label1.Text = "Jewellery Shop Management System";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OldLace;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1370, 87);
            this.panel1.TabIndex = 18;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OldLace;
            this.panel2.Controls.Add(this.btnHome);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.buttonAddCustomers);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.buttonCreateInvoice);
            this.panel2.Controls.Add(this.btnListItem);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(216, 662);
            this.panel2.TabIndex = 19;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.OldLace;
            this.panel3.Controls.Add(this.lbltime);
            this.panel3.Controls.Add(this.monthCalendar1);
            this.panel3.Location = new System.Drawing.Point(1139, 86);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(231, 205);
            this.panel3.TabIndex = 20;
            this.panel3.Visible = false;
            this.panel3.DragLeave += new System.EventHandler(this.panel3_DragLeave);
            this.panel3.Leave += new System.EventHandler(this.panel3_Leave);
            this.panel3.MouseLeave += new System.EventHandler(this.panel3_MouseLeave);
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.Location = new System.Drawing.Point(17, 15);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(17, 21);
            this.lbltime.TabIndex = 21;
            this.lbltime.Text = "*";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(3, 42);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 21;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Venkatesh Jewellers - Billing System";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonCreateInvoice;
        private System.Windows.Forms.Button btnListItem;
        private System.Windows.Forms.Button buttonAddCustomers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Timer timer1;
    }
}

