﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.OleDb;

namespace BillingSystem
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }
        string cs = ConfigurationManager.ConnectionStrings["BillingSystem.Properties.Settings.BillingDBConnectionString"].ConnectionString;


     
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtusername.Text) == true)
            {
                errorProvider1.SetError(this.txtusername, "Please Enter The UserName ...");
                txtusername.Focus();
            }
            else if (string.IsNullOrEmpty(txtpassword.Text) == true)
            {
                errorProvider2.SetError(this.txtpassword, "Please Enter The Password ....");
                txtpassword.Focus();
            }
            else
            {
                OleDbConnection con = new OleDbConnection(cs);
                string query = "select *from LoginTbl where username=@uname and password=@pass";
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.Parameters.AddWithValue("@uname", txtusername.Text);
                cmd.Parameters.AddWithValue("@pass", txtpassword.Text);
                con.Open();
                OleDbDataReader dr = cmd.ExecuteReader();
                
               

                if (dr.HasRows)
                {
                    MessageBox.Show("User Login Successfuly...","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);

                   

                    txtusername.Clear();
                    txtpassword.Clear();
                                        
                    Main l = new Main();
                    l.Show();
                    this.Close();


                }
                else
                {
                    MessageBox.Show("Login Faild","Information",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    txtusername.Clear();
                    txtpassword.Clear();

                }

            }

        
        }


        private void txtusername_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtusername.Text)==true)
            {
                errorProvider1.SetError(this.txtusername, "Please Enter The UserName ...");
                txtusername.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void txtpassword_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtpassword.Text)==true)
            {
                errorProvider2.SetError(this.txtpassword, "Please Enter The Password ....");
                txtpassword.Focus();
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtusername.Clear();
            txtpassword.Clear();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else if (checkBox1.Checked==false)
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }
    }
}
