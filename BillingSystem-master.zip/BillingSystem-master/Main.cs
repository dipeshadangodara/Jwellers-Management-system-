﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace BillingSystem
{
    public partial class Main : Form
    {
        public static Color brandColor = Color.FromArgb(94, 2, 42); // HTML code:	#5E022A
        public static Color yellowColor = Color.FromArgb(248, 189, 68); // HTML code:	#F8BD44

        public static void SetControlsColor(Form form)
        {
            form.BackColor = Main.brandColor;
            foreach (Control c in form.Controls)
            {
                if (c.GetType() == typeof(Label))
                {
                    c.ForeColor = Color.White;
                }
                else if (c.GetType() == typeof(TextBox))
                {
                    c.BackColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(DateTimePicker))
                {
                    c.BackColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(Button))
                {
                    c.BackColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(ComboBox))
                {
                    c.BackColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(PrintPreviewControl))
                {
                    c.ForeColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(DataGridView))
                {
                    ((DataGridView)c).BackgroundColor = Main.brandColor;
                    ((DataGridView)c).RowsDefaultCellStyle.BackColor = Main.yellowColor;
                    ((DataGridView)c).ColumnHeadersDefaultCellStyle.ForeColor = Main.brandColor;
                    ((DataGridView)c).ColumnHeadersDefaultCellStyle.BackColor = Main.brandColor;
                    ((DataGridView)c).RowHeadersDefaultCellStyle.BackColor = Main.yellowColor;
                }
                else if (c.GetType() == typeof(BindingNavigator))
                {
                    c.BackColor = Main.brandColor;
                    foreach (var item in ((BindingNavigator)c).Items)
                    {
                        if (item.GetType() == typeof(ToolStripButton))
                        {
                            //((ToolStripButton)item).BackColor = Main.yellowColor;
                        }
                        if (item.GetType() == typeof(ToolStripTextBox))
                        {
                            ((ToolStripTextBox)item).BackColor = Main.yellowColor; ;
                        }
                        else if (item.GetType() == typeof(ToolStripLabel))
                        {
                            ((ToolStripLabel)item).ForeColor = Color.White;
                        }
                    }
                }
                else if (c.GetType() == typeof(GroupBox))
                {
                    c.ForeColor = Color.White;
                    foreach (Control gc in c.Controls)
                    {
                        if (gc.GetType() == typeof(Label))
                        {
                            gc.ForeColor = Color.White;
                        }
                        else if (gc.GetType() == typeof(TextBox))
                        {
                            gc.BackColor = Main.yellowColor;
                        }
                        else if (gc.GetType() == typeof(Button))
                        {
                            gc.ForeColor = Color.Black;
                            gc.BackColor = Main.yellowColor;
                        }
                        else if (gc.GetType() == typeof(ComboBox))
                        {
                            gc.BackColor = Main.yellowColor;
                        }
                        else if (gc.GetType() == typeof(RadioButton))
                        {
                            gc.ForeColor = Color.White;
                            gc.BackColor = Main.brandColor;
                        }
                        else if (gc.GetType() == typeof(CheckBox))
                        {
                            gc.ForeColor = Color.White;
                            gc.BackColor = Main.brandColor;
                        }
                        else
                            gc.BackColor = Main.yellowColor;
                    }
                }
            }
        }

        public Main()
        {
            InitializeComponent();
            SetControlsColor(this);
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // Set cursor as hourglass
            Cursor.Current = Cursors.WaitCursor;

            // TODO: Do Something here...

            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;
            HomePage p = new HomePage();
            p.MdiParent = this;
            p.Show();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonAddCustomers_Click(object sender, EventArgs e)
        {
            Customers customersForm = new Customers();
            customersForm.MdiParent = this;
            customersForm.Show();
        }

        private void buttonAddItems_Click(object sender, EventArgs e)
        {
            //Items itemsForm = new Items();
            //itemsForm.MdiParent = this;
            //itemsForm.Show();
            ListAllItemPage l = new ListAllItemPage();
            l.MdiParent = this;
            l.Show();
        }

        private void buttonCreateInvoice_Click(object sender, EventArgs e)
        {
            Invoices invoicesForm = new Invoices();
            invoicesForm.MdiParent = this;
            invoicesForm.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            DialogResult dr = MessageBox.Show("Are You Sure You Want To Logout From The Software ..... !", "Logout Information ",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomePage p = new HomePage();
            p.MdiParent = this;
            p.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerListPage customersForm = new CustomerListPage();
            customersForm.MdiParent = this;
            customersForm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SoldItems s = new SoldItems();
            s.MdiParent = this;
            s.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = "Time : " + DateTime.Now.ToString("hh : MM : ss - tt");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }

        private void panel3_DragLeave(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void panel3_Leave(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UserPage page = new UserPage();
            page.MdiParent = this;
            page.Show();
        }
    }
}
