﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BillingSystem
{
    public partial class ProgressBarPage : Form
    {
        public ProgressBarPage()
        {
            InitializeComponent();
        }

        int i = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = i.ToString() + "%";
            //   this.Text = "Progress (" + i.ToString() + "%)";
            progressBar1.Value = i;
            if (i == 100)
            {
                timer1.Enabled = false;
                LoginPage l = new LoginPage();
                l.Show();
                this.Hide();
            }
            i = i + 1;
        }
    }
}
