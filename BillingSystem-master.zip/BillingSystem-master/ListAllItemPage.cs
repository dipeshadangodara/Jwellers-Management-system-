﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Configuration;

namespace BillingSystem
{
    public partial class ListAllItemPage : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["BillingSystem.Properties.Settings.BillingDBConnectionString"].ConnectionString;

        public ListAllItemPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     

        public void Bind()
        {
            OleDbConnection con = new OleDbConnection(cs);
            string query = "select *from Items";
            //OleDbCommand cmd = new OleDbCommand(query,con);
            //con.Open();
            OleDbDataAdapter sda = new OleDbDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            customersDataGridView.DataSource = data;
        }

        private void ListAllItemPage_Load(object sender, EventArgs e)
        {
            Bind();
        }
    }
}
