﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.OleDb;

namespace BillingSystem
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }
        int imgnumber=1;

        string cs = ConfigurationManager.ConnectionStrings["BillingSystem.Properties.Settings.BillingDBConnectionString"].ConnectionString;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (imgnumber >= 8)
            {
                imgnumber = 1;
            }
            pictureBox1.ImageLocation = string.Format(@"E:\Other Projects\BillingSystem-master\Image\" + imgnumber + ".JPEG");
            imgnumber = imgnumber + 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        public void CustomeerList()
        {
             OleDbConnection con = new OleDbConnection(cs);
            string query = "select count(ID) from Customers";
            OleDbCommand cmd = new OleDbCommand(query, con);
            con.Open();
            int a = Convert.ToInt32(cmd.ExecuteScalar());
            label5.Text = a.ToString();
            con.Close();
        }

        public void ItemsList()
        {
            OleDbConnection con = new OleDbConnection(cs);
            string query = "select count(ID) from Items";
            OleDbCommand cmd = new OleDbCommand(query, con);
            con.Open();
            int a = Convert.ToInt32(cmd.ExecuteScalar());
            label6.Text = a.ToString();
            con.Close();
        }
        public void ItemsSoldList()
        {
            OleDbConnection con = new OleDbConnection(cs);
            string query = "select count(InvoiceNo) from ItemsSold";
            OleDbCommand cmd = new OleDbCommand(query, con);
            con.Open();
            int a = Convert.ToInt32(cmd.ExecuteScalar());
            label7.Text = a.ToString();
            con.Close();
        }
        private void HomePage_Load(object sender, EventArgs e)
        {
            CustomeerList();
            ItemsSoldList();
            ItemsList();
        }
    }
}
