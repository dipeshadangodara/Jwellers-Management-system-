﻿namespace BillingSystem
{
    partial class Invoices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label itemCodeLabel;
            System.Windows.Forms.Label itemNameLabel;
            System.Windows.Forms.Label pcsLabel;
            System.Windows.Forms.Label grossWeightLabel;
            System.Windows.Forms.Label wtChkLabel;
            System.Windows.Forms.Label netWeightLabel;
            System.Windows.Forms.Label hishobLabel;
            System.Windows.Forms.Label tunchLabel;
            System.Windows.Forms.Label labourRateLabel;
            System.Windows.Forms.Label fineLabel;
            System.Windows.Forms.Label labourLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Invoices));
            this.billBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.billingDBDataSet = new BillingSystem.BillingDBDataSet();
            this.billTableAdapter = new BillingSystem.BillingDBDataSetTableAdapters.BillTableAdapter();
            this.tableAdapterManager = new BillingSystem.BillingDBDataSetTableAdapters.TableAdapterManager();
            this.customersTableAdapter = new BillingSystem.BillingDBDataSetTableAdapters.CustomersTableAdapter();
            this.invoicesTableAdapter = new BillingSystem.BillingDBDataSetTableAdapters.InvoicesTableAdapter();
            this.itemsSoldTableAdapter = new BillingSystem.BillingDBDataSetTableAdapters.ItemsSoldTableAdapter();
            this.itemsTableAdapter = new BillingSystem.BillingDBDataSetTableAdapters.ItemsTableAdapter();
            this.billDataGridView = new System.Windows.Forms.DataGridView();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemCodeTextBox = new System.Windows.Forms.TextBox();
            this.pcsTextBox = new System.Windows.Forms.TextBox();
            this.grossWeightTextBox = new System.Windows.Forms.TextBox();
            this.wtChkTextBox = new System.Windows.Forms.TextBox();
            this.netWeightTextBox = new System.Windows.Forms.TextBox();
            this.hishobTextBox = new System.Windows.Forms.TextBox();
            this.tunchTextBox = new System.Windows.Forms.TextBox();
            this.labourRateTextBox = new System.Windows.Forms.TextBox();
            this.fineTextBox = new System.Windows.Forms.TextBox();
            this.labourTextBox = new System.Windows.Forms.TextBox();
            this.groupBoxNewItem = new System.Windows.Forms.GroupBox();
            this.selectItemsComboBox = new System.Windows.Forms.ComboBox();
            this.buttonNewItem = new System.Windows.Forms.Button();
            this.buttonAddItem = new System.Windows.Forms.Button();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.invoicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsSoldBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.selectCustomerComboBox = new System.Windows.Forms.ComboBox();
            this.selectCustomerLabel = new System.Windows.Forms.Label();
            this.groupBoxItemEntryMode = new System.Windows.Forms.GroupBox();
            this.radioButtonRegular = new System.Windows.Forms.RadioButton();
            this.radioButtonPerKg = new System.Windows.Forms.RadioButton();
            this.radioButtonPerPcs = new System.Windows.Forms.RadioButton();
            this.buttonAddNewCustomer = new System.Windows.Forms.Button();
            this.clearEntryButton = new System.Windows.Forms.Button();
            this.buttonUpdateItem = new System.Windows.Forms.Button();
            this.buttonDeleteSelected = new System.Windows.Forms.Button();
            this.invoiceDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.labelTotal = new System.Windows.Forms.Label();
            this.textBoxTotalGrossWeight = new System.Windows.Forms.TextBox();
            this.labelDummy1 = new System.Windows.Forms.Label();
            this.textBoxTotalNetWeight = new System.Windows.Forms.TextBox();
            this.labelDummy2 = new System.Windows.Forms.Label();
            this.textBoxTotalFine = new System.Windows.Forms.TextBox();
            this.textBoxTotalLabour = new System.Windows.Forms.TextBox();
            this.buttonPrint = new System.Windows.Forms.Button();
            this.buttonSaveInvoice = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonExportToExcel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            itemCodeLabel = new System.Windows.Forms.Label();
            itemNameLabel = new System.Windows.Forms.Label();
            pcsLabel = new System.Windows.Forms.Label();
            grossWeightLabel = new System.Windows.Forms.Label();
            wtChkLabel = new System.Windows.Forms.Label();
            netWeightLabel = new System.Windows.Forms.Label();
            hishobLabel = new System.Windows.Forms.Label();
            tunchLabel = new System.Windows.Forms.Label();
            labourRateLabel = new System.Windows.Forms.Label();
            fineLabel = new System.Windows.Forms.Label();
            labourLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.billBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            this.groupBoxNewItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSoldBindingSource)).BeginInit();
            this.groupBoxItemEntryMode.SuspendLayout();
            this.SuspendLayout();
            // 
            // itemCodeLabel
            // 
            itemCodeLabel.AutoSize = true;
            itemCodeLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            itemCodeLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            itemCodeLabel.Location = new System.Drawing.Point(4, 73);
            itemCodeLabel.Name = "itemCodeLabel";
            itemCodeLabel.Size = new System.Drawing.Size(78, 16);
            itemCodeLabel.TabIndex = 4;
            itemCodeLabel.Text = "Item Code:";
            // 
            // itemNameLabel
            // 
            itemNameLabel.AutoSize = true;
            itemNameLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            itemNameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            itemNameLabel.Location = new System.Drawing.Point(208, 41);
            itemNameLabel.Name = "itemNameLabel";
            itemNameLabel.Size = new System.Drawing.Size(82, 16);
            itemNameLabel.TabIndex = 5;
            itemNameLabel.Text = "Item Name:";
            // 
            // pcsLabel
            // 
            pcsLabel.AutoSize = true;
            pcsLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            pcsLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            pcsLabel.Location = new System.Drawing.Point(34, 118);
            pcsLabel.Name = "pcsLabel";
            pcsLabel.Size = new System.Drawing.Size(34, 16);
            pcsLabel.TabIndex = 6;
            pcsLabel.Text = "Pcs:";
            // 
            // grossWeightLabel
            // 
            grossWeightLabel.AutoSize = true;
            grossWeightLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            grossWeightLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            grossWeightLabel.Location = new System.Drawing.Point(216, 114);
            grossWeightLabel.Name = "grossWeightLabel";
            grossWeightLabel.Size = new System.Drawing.Size(99, 16);
            grossWeightLabel.TabIndex = 8;
            grossWeightLabel.Text = "Gross Weight:";
            // 
            // wtChkLabel
            // 
            wtChkLabel.AutoSize = true;
            wtChkLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            wtChkLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            wtChkLabel.Location = new System.Drawing.Point(479, 109);
            wtChkLabel.Name = "wtChkLabel";
            wtChkLabel.Size = new System.Drawing.Size(62, 16);
            wtChkLabel.TabIndex = 10;
            wtChkLabel.Text = "Wt Chk:";
            // 
            // netWeightLabel
            // 
            netWeightLabel.AutoSize = true;
            netWeightLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            netWeightLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            netWeightLabel.Location = new System.Drawing.Point(661, 76);
            netWeightLabel.Name = "netWeightLabel";
            netWeightLabel.Size = new System.Drawing.Size(85, 16);
            netWeightLabel.TabIndex = 12;
            netWeightLabel.Text = "Net Weight:";
            // 
            // hishobLabel
            // 
            hishobLabel.AutoSize = true;
            hishobLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            hishobLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            hishobLabel.Location = new System.Drawing.Point(19, 160);
            hishobLabel.Name = "hishobLabel";
            hishobLabel.Size = new System.Drawing.Size(58, 16);
            hishobLabel.TabIndex = 14;
            hishobLabel.Text = "Hishob:";
            // 
            // tunchLabel
            // 
            tunchLabel.AutoSize = true;
            tunchLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            tunchLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            tunchLabel.Location = new System.Drawing.Point(238, 160);
            tunchLabel.Name = "tunchLabel";
            tunchLabel.Size = new System.Drawing.Size(70, 16);
            tunchLabel.TabIndex = 16;
            tunchLabel.Text = "Tunch %:";
            // 
            // labourRateLabel
            // 
            labourRateLabel.AutoSize = true;
            labourRateLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            labourRateLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            labourRateLabel.Location = new System.Drawing.Point(456, 154);
            labourRateLabel.Name = "labourRateLabel";
            labourRateLabel.Size = new System.Drawing.Size(91, 16);
            labourRateLabel.TabIndex = 18;
            labourRateLabel.Text = "Labour Rate:";
            // 
            // fineLabel
            // 
            fineLabel.AutoSize = true;
            fineLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            fineLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            fineLabel.Location = new System.Drawing.Point(695, 120);
            fineLabel.Name = "fineLabel";
            fineLabel.Size = new System.Drawing.Size(40, 16);
            fineLabel.TabIndex = 20;
            fineLabel.Text = "Fine:";
            // 
            // labourLabel
            // 
            labourLabel.AutoSize = true;
            labourLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            labourLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            labourLabel.Location = new System.Drawing.Point(682, 160);
            labourLabel.Name = "labourLabel";
            labourLabel.Size = new System.Drawing.Size(58, 16);
            labourLabel.TabIndex = 22;
            labourLabel.Text = "Labour:";
            // 
            // billBindingSource
            // 
            this.billBindingSource.DataMember = "Bill";
            this.billBindingSource.DataSource = this.billingDBDataSet;
            // 
            // billingDBDataSet
            // 
            this.billingDBDataSet.DataSetName = "BillingDBDataSet";
            this.billingDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // billTableAdapter
            // 
            this.billTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomersTableAdapter = this.customersTableAdapter;
            this.tableAdapterManager.InvoicesTableAdapter = this.invoicesTableAdapter;
            this.tableAdapterManager.ItemsSoldTableAdapter = this.itemsSoldTableAdapter;
            this.tableAdapterManager.ItemsTableAdapter = this.itemsTableAdapter;
            this.tableAdapterManager.UpdateOrder = BillingSystem.BillingDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // invoicesTableAdapter
            // 
            this.invoicesTableAdapter.ClearBeforeFill = true;
            // 
            // itemsSoldTableAdapter
            // 
            this.itemsSoldTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // billDataGridView
            // 
            this.billDataGridView.AllowUserToResizeColumns = false;
            this.billDataGridView.AllowUserToResizeRows = false;
            this.billDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.billDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.billDataGridView.GridColor = System.Drawing.Color.White;
            this.billDataGridView.Location = new System.Drawing.Point(18, 421);
            this.billDataGridView.Name = "billDataGridView";
            this.billDataGridView.ReadOnly = true;
            this.billDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.billDataGridView.Size = new System.Drawing.Size(1121, 161);
            this.billDataGridView.TabIndex = 4;
            this.billDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.billDataGridView_CellClick);
            this.billDataGridView.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.billDataGridView_CellPainting);
            this.billDataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.billDataGridView_RowsAdded);
            this.billDataGridView.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.billDataGridView_RowsRemoved);
            this.billDataGridView.SelectionChanged += new System.EventHandler(this.billDataGridView_SelectionChanged);
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.billingDBDataSet;
            // 
            // itemCodeTextBox
            // 
            this.itemCodeTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.itemCodeTextBox.Location = new System.Drawing.Point(85, 72);
            this.itemCodeTextBox.Name = "itemCodeTextBox";
            this.itemCodeTextBox.Size = new System.Drawing.Size(100, 22);
            this.itemCodeTextBox.TabIndex = 5;
            this.itemCodeTextBox.Enter += new System.EventHandler(this.itemCodeTextBox_Enter);
            this.itemCodeTextBox.Leave += new System.EventHandler(this.itemCodeTextBox_Leave);
            // 
            // pcsTextBox
            // 
            this.pcsTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.pcsTextBox.Location = new System.Drawing.Point(85, 116);
            this.pcsTextBox.Name = "pcsTextBox";
            this.pcsTextBox.Size = new System.Drawing.Size(100, 22);
            this.pcsTextBox.TabIndex = 7;
            this.pcsTextBox.Leave += new System.EventHandler(this.pcsTextBox_Leave);
            // 
            // grossWeightTextBox
            // 
            this.grossWeightTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.grossWeightTextBox.Location = new System.Drawing.Point(326, 108);
            this.grossWeightTextBox.Name = "grossWeightTextBox";
            this.grossWeightTextBox.Size = new System.Drawing.Size(100, 22);
            this.grossWeightTextBox.TabIndex = 9;
            this.grossWeightTextBox.Leave += new System.EventHandler(this.grossWeightTextBox_Leave);
            // 
            // wtChkTextBox
            // 
            this.wtChkTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.wtChkTextBox.Location = new System.Drawing.Point(557, 106);
            this.wtChkTextBox.Name = "wtChkTextBox";
            this.wtChkTextBox.Size = new System.Drawing.Size(100, 22);
            this.wtChkTextBox.TabIndex = 11;
            this.wtChkTextBox.Leave += new System.EventHandler(this.wtChkTextBox_Leave);
            // 
            // netWeightTextBox
            // 
            this.netWeightTextBox.Enabled = false;
            this.netWeightTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.netWeightTextBox.Location = new System.Drawing.Point(757, 73);
            this.netWeightTextBox.Name = "netWeightTextBox";
            this.netWeightTextBox.Size = new System.Drawing.Size(100, 22);
            this.netWeightTextBox.TabIndex = 13;
            this.netWeightTextBox.Leave += new System.EventHandler(this.netWeightTextBox_Leave);
            // 
            // hishobTextBox
            // 
            this.hishobTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.hishobTextBox.Location = new System.Drawing.Point(85, 159);
            this.hishobTextBox.Name = "hishobTextBox";
            this.hishobTextBox.Size = new System.Drawing.Size(100, 22);
            this.hishobTextBox.TabIndex = 15;
            this.hishobTextBox.Leave += new System.EventHandler(this.hishobTextBox_Leave);
            // 
            // tunchTextBox
            // 
            this.tunchTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.tunchTextBox.Location = new System.Drawing.Point(326, 152);
            this.tunchTextBox.Name = "tunchTextBox";
            this.tunchTextBox.Size = new System.Drawing.Size(100, 22);
            this.tunchTextBox.TabIndex = 17;
            this.tunchTextBox.Leave += new System.EventHandler(this.tunchTextBox_Leave);
            // 
            // labourRateTextBox
            // 
            this.labourRateTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.labourRateTextBox.Location = new System.Drawing.Point(557, 148);
            this.labourRateTextBox.Name = "labourRateTextBox";
            this.labourRateTextBox.Size = new System.Drawing.Size(100, 22);
            this.labourRateTextBox.TabIndex = 19;
            this.labourRateTextBox.Leave += new System.EventHandler(this.labourRateTextBox_Leave);
            // 
            // fineTextBox
            // 
            this.fineTextBox.Enabled = false;
            this.fineTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.fineTextBox.Location = new System.Drawing.Point(757, 115);
            this.fineTextBox.Name = "fineTextBox";
            this.fineTextBox.Size = new System.Drawing.Size(100, 22);
            this.fineTextBox.TabIndex = 21;
            // 
            // labourTextBox
            // 
            this.labourTextBox.Enabled = false;
            this.labourTextBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.labourTextBox.Location = new System.Drawing.Point(757, 157);
            this.labourTextBox.Name = "labourTextBox";
            this.labourTextBox.Size = new System.Drawing.Size(100, 22);
            this.labourTextBox.TabIndex = 23;
            // 
            // groupBoxNewItem
            // 
            this.groupBoxNewItem.Controls.Add(this.selectItemsComboBox);
            this.groupBoxNewItem.Controls.Add(this.buttonNewItem);
            this.groupBoxNewItem.Controls.Add(labourLabel);
            this.groupBoxNewItem.Controls.Add(itemCodeLabel);
            this.groupBoxNewItem.Controls.Add(this.labourTextBox);
            this.groupBoxNewItem.Controls.Add(fineLabel);
            this.groupBoxNewItem.Controls.Add(this.fineTextBox);
            this.groupBoxNewItem.Controls.Add(labourRateLabel);
            this.groupBoxNewItem.Controls.Add(this.labourRateTextBox);
            this.groupBoxNewItem.Controls.Add(tunchLabel);
            this.groupBoxNewItem.Controls.Add(this.tunchTextBox);
            this.groupBoxNewItem.Controls.Add(hishobLabel);
            this.groupBoxNewItem.Controls.Add(this.hishobTextBox);
            this.groupBoxNewItem.Controls.Add(netWeightLabel);
            this.groupBoxNewItem.Controls.Add(this.netWeightTextBox);
            this.groupBoxNewItem.Controls.Add(wtChkLabel);
            this.groupBoxNewItem.Controls.Add(this.wtChkTextBox);
            this.groupBoxNewItem.Controls.Add(grossWeightLabel);
            this.groupBoxNewItem.Controls.Add(this.grossWeightTextBox);
            this.groupBoxNewItem.Controls.Add(pcsLabel);
            this.groupBoxNewItem.Controls.Add(this.pcsTextBox);
            this.groupBoxNewItem.Controls.Add(itemNameLabel);
            this.groupBoxNewItem.Controls.Add(this.itemCodeTextBox);
            this.groupBoxNewItem.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.groupBoxNewItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBoxNewItem.Location = new System.Drawing.Point(202, 130);
            this.groupBoxNewItem.Name = "groupBoxNewItem";
            this.groupBoxNewItem.Size = new System.Drawing.Size(876, 221);
            this.groupBoxNewItem.TabIndex = 24;
            this.groupBoxNewItem.TabStop = false;
            this.groupBoxNewItem.Text = "Item Entry";
            this.groupBoxNewItem.Enter += new System.EventHandler(this.groupBoxNewItem_Enter);
            // 
            // selectItemsComboBox
            // 
            this.selectItemsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectItemsComboBox.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F);
            this.selectItemsComboBox.FormattingEnabled = true;
            this.selectItemsComboBox.Location = new System.Drawing.Point(296, 41);
            this.selectItemsComboBox.Name = "selectItemsComboBox";
            this.selectItemsComboBox.Size = new System.Drawing.Size(309, 22);
            this.selectItemsComboBox.Sorted = true;
            this.selectItemsComboBox.TabIndex = 25;
            this.selectItemsComboBox.SelectedIndexChanged += new System.EventHandler(this.selectItemsComboBox_SelectedIndexChanged);
            // 
            // buttonNewItem
            // 
            this.buttonNewItem.Location = new System.Drawing.Point(611, 41);
            this.buttonNewItem.Name = "buttonNewItem";
            this.buttonNewItem.Size = new System.Drawing.Size(26, 23);
            this.buttonNewItem.TabIndex = 24;
            this.buttonNewItem.Text = "...";
            this.buttonNewItem.UseVisualStyleBackColor = true;
            this.buttonNewItem.Click += new System.EventHandler(this.buttonNewItem_Click);
            // 
            // buttonAddItem
            // 
            this.buttonAddItem.BackColor = System.Drawing.Color.LightYellow;
            this.buttonAddItem.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonAddItem.FlatAppearance.CheckedBackColor = System.Drawing.Color.Snow;
            this.buttonAddItem.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonAddItem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonAddItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonAddItem.Location = new System.Drawing.Point(355, 357);
            this.buttonAddItem.Name = "buttonAddItem";
            this.buttonAddItem.Size = new System.Drawing.Size(100, 32);
            this.buttonAddItem.TabIndex = 25;
            this.buttonAddItem.Text = "Add";
            this.buttonAddItem.UseVisualStyleBackColor = false;
            this.buttonAddItem.Click += new System.EventHandler(this.buttonAddItem_Click);
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.billingDBDataSet;
            // 
            // invoicesBindingSource
            // 
            this.invoicesBindingSource.DataMember = "Invoices";
            this.invoicesBindingSource.DataSource = this.billingDBDataSet;
            // 
            // itemsSoldBindingSource
            // 
            this.itemsSoldBindingSource.DataMember = "ItemsSold";
            this.itemsSoldBindingSource.DataSource = this.billingDBDataSet;
            // 
            // selectCustomerComboBox
            // 
            this.selectCustomerComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectCustomerComboBox.FormattingEnabled = true;
            this.selectCustomerComboBox.Location = new System.Drawing.Point(421, 108);
            this.selectCustomerComboBox.Name = "selectCustomerComboBox";
            this.selectCustomerComboBox.Size = new System.Drawing.Size(309, 21);
            this.selectCustomerComboBox.Sorted = true;
            this.selectCustomerComboBox.TabIndex = 29;
            this.selectCustomerComboBox.SelectedIndexChanged += new System.EventHandler(this.selectCustomerComboBox_SelectedIndexChanged);
            // 
            // selectCustomerLabel
            // 
            this.selectCustomerLabel.AutoSize = true;
            this.selectCustomerLabel.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.selectCustomerLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.selectCustomerLabel.Location = new System.Drawing.Point(296, 109);
            this.selectCustomerLabel.Name = "selectCustomerLabel";
            this.selectCustomerLabel.Size = new System.Drawing.Size(119, 16);
            this.selectCustomerLabel.TabIndex = 30;
            this.selectCustomerLabel.Text = "Select Customer: ";
            // 
            // groupBoxItemEntryMode
            // 
            this.groupBoxItemEntryMode.Controls.Add(this.radioButtonRegular);
            this.groupBoxItemEntryMode.Controls.Add(this.radioButtonPerKg);
            this.groupBoxItemEntryMode.Controls.Add(this.radioButtonPerPcs);
            this.groupBoxItemEntryMode.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.groupBoxItemEntryMode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBoxItemEntryMode.Location = new System.Drawing.Point(25, 161);
            this.groupBoxItemEntryMode.Name = "groupBoxItemEntryMode";
            this.groupBoxItemEntryMode.Size = new System.Drawing.Size(136, 181);
            this.groupBoxItemEntryMode.TabIndex = 32;
            this.groupBoxItemEntryMode.TabStop = false;
            this.groupBoxItemEntryMode.Text = "Select Mode";
            // 
            // radioButtonRegular
            // 
            this.radioButtonRegular.AutoSize = true;
            this.radioButtonRegular.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.radioButtonRegular.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioButtonRegular.Location = new System.Drawing.Point(38, 129);
            this.radioButtonRegular.Name = "radioButtonRegular";
            this.radioButtonRegular.Size = new System.Drawing.Size(76, 20);
            this.radioButtonRegular.TabIndex = 30;
            this.radioButtonRegular.Text = "Ragular";
            this.radioButtonRegular.UseVisualStyleBackColor = true;
            this.radioButtonRegular.CheckedChanged += new System.EventHandler(this.radioButtonRegular_CheckedChanged);
            // 
            // radioButtonPerKg
            // 
            this.radioButtonPerKg.AutoSize = true;
            this.radioButtonPerKg.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.radioButtonPerKg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioButtonPerKg.Location = new System.Drawing.Point(38, 87);
            this.radioButtonPerKg.Name = "radioButtonPerKg";
            this.radioButtonPerKg.Size = new System.Drawing.Size(71, 20);
            this.radioButtonPerKg.TabIndex = 29;
            this.radioButtonPerKg.Text = "Per Kg";
            this.radioButtonPerKg.UseVisualStyleBackColor = true;
            this.radioButtonPerKg.CheckedChanged += new System.EventHandler(this.radioButtonPerKg_CheckedChanged);
            // 
            // radioButtonPerPcs
            // 
            this.radioButtonPerPcs.AutoSize = true;
            this.radioButtonPerPcs.Checked = true;
            this.radioButtonPerPcs.Font = new System.Drawing.Font("Mongolian Baiti", 12F);
            this.radioButtonPerPcs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioButtonPerPcs.Location = new System.Drawing.Point(38, 42);
            this.radioButtonPerPcs.Name = "radioButtonPerPcs";
            this.radioButtonPerPcs.Size = new System.Drawing.Size(84, 20);
            this.radioButtonPerPcs.TabIndex = 0;
            this.radioButtonPerPcs.TabStop = true;
            this.radioButtonPerPcs.Text = "Per Pices";
            this.radioButtonPerPcs.UseVisualStyleBackColor = true;
            this.radioButtonPerPcs.CheckedChanged += new System.EventHandler(this.radioButtonPerPcs_CheckedChanged);
            // 
            // buttonAddNewCustomer
            // 
            this.buttonAddNewCustomer.Location = new System.Drawing.Point(736, 106);
            this.buttonAddNewCustomer.Name = "buttonAddNewCustomer";
            this.buttonAddNewCustomer.Size = new System.Drawing.Size(24, 23);
            this.buttonAddNewCustomer.TabIndex = 33;
            this.buttonAddNewCustomer.Text = "...";
            this.buttonAddNewCustomer.UseVisualStyleBackColor = true;
            this.buttonAddNewCustomer.Click += new System.EventHandler(this.buttonAddNewCustomer_Click);
            // 
            // clearEntryButton
            // 
            this.clearEntryButton.BackColor = System.Drawing.Color.LightYellow;
            this.clearEntryButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.clearEntryButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.Snow;
            this.clearEntryButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.clearEntryButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.clearEntryButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearEntryButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.clearEntryButton.Location = new System.Drawing.Point(783, 357);
            this.clearEntryButton.Name = "clearEntryButton";
            this.clearEntryButton.Size = new System.Drawing.Size(100, 32);
            this.clearEntryButton.TabIndex = 34;
            this.clearEntryButton.Text = "Clear Entry";
            this.clearEntryButton.UseVisualStyleBackColor = false;
            this.clearEntryButton.Click += new System.EventHandler(this.clearEntryButton_Click);
            // 
            // buttonUpdateItem
            // 
            this.buttonUpdateItem.BackColor = System.Drawing.Color.LightYellow;
            this.buttonUpdateItem.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonUpdateItem.FlatAppearance.CheckedBackColor = System.Drawing.Color.Snow;
            this.buttonUpdateItem.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonUpdateItem.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonUpdateItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUpdateItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonUpdateItem.Location = new System.Drawing.Point(502, 357);
            this.buttonUpdateItem.Name = "buttonUpdateItem";
            this.buttonUpdateItem.Size = new System.Drawing.Size(100, 32);
            this.buttonUpdateItem.TabIndex = 35;
            this.buttonUpdateItem.Text = "Update";
            this.buttonUpdateItem.UseVisualStyleBackColor = false;
            this.buttonUpdateItem.Click += new System.EventHandler(this.buttonUpdateItem_Click);
            // 
            // buttonDeleteSelected
            // 
            this.buttonDeleteSelected.BackColor = System.Drawing.Color.LightYellow;
            this.buttonDeleteSelected.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonDeleteSelected.FlatAppearance.CheckedBackColor = System.Drawing.Color.Snow;
            this.buttonDeleteSelected.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonDeleteSelected.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonDeleteSelected.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonDeleteSelected.Location = new System.Drawing.Point(644, 357);
            this.buttonDeleteSelected.Name = "buttonDeleteSelected";
            this.buttonDeleteSelected.Size = new System.Drawing.Size(100, 32);
            this.buttonDeleteSelected.TabIndex = 36;
            this.buttonDeleteSelected.Text = "Delete Selected";
            this.buttonDeleteSelected.UseVisualStyleBackColor = false;
            this.buttonDeleteSelected.Click += new System.EventHandler(this.buttonDeleteSelected_Click);
            // 
            // invoiceDateTimePicker
            // 
            this.invoiceDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.invoicesBindingSource, "InvoiceDate", true));
            this.invoiceDateTimePicker.Location = new System.Drawing.Point(813, 109);
            this.invoiceDateTimePicker.Name = "invoiceDateTimePicker";
            this.invoiceDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.invoiceDateTimePicker.TabIndex = 37;
            // 
            // labelTotal
            // 
            this.labelTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(18, 582);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(521, 20);
            this.labelTotal.TabIndex = 38;
            this.labelTotal.Text = "Total: ";
            this.labelTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxTotalGrossWeight
            // 
            this.textBoxTotalGrossWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalGrossWeight.Location = new System.Drawing.Point(536, 582);
            this.textBoxTotalGrossWeight.Name = "textBoxTotalGrossWeight";
            this.textBoxTotalGrossWeight.Size = new System.Drawing.Size(81, 20);
            this.textBoxTotalGrossWeight.TabIndex = 39;
            // 
            // labelDummy1
            // 
            this.labelDummy1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDummy1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDummy1.Location = new System.Drawing.Point(616, 582);
            this.labelDummy1.Name = "labelDummy1";
            this.labelDummy1.Size = new System.Drawing.Size(52, 20);
            this.labelDummy1.TabIndex = 40;
            this.labelDummy1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxTotalNetWeight
            // 
            this.textBoxTotalNetWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalNetWeight.Location = new System.Drawing.Point(667, 582);
            this.textBoxTotalNetWeight.Name = "textBoxTotalNetWeight";
            this.textBoxTotalNetWeight.Size = new System.Drawing.Size(90, 20);
            this.textBoxTotalNetWeight.TabIndex = 41;
            // 
            // labelDummy2
            // 
            this.labelDummy2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelDummy2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDummy2.Location = new System.Drawing.Point(756, 582);
            this.labelDummy2.Name = "labelDummy2";
            this.labelDummy2.Size = new System.Drawing.Size(224, 20);
            this.labelDummy2.TabIndex = 42;
            this.labelDummy2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxTotalFine
            // 
            this.textBoxTotalFine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalFine.Location = new System.Drawing.Point(978, 582);
            this.textBoxTotalFine.Name = "textBoxTotalFine";
            this.textBoxTotalFine.Size = new System.Drawing.Size(80, 20);
            this.textBoxTotalFine.TabIndex = 43;
            // 
            // textBoxTotalLabour
            // 
            this.textBoxTotalLabour.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalLabour.Location = new System.Drawing.Point(1057, 582);
            this.textBoxTotalLabour.Name = "textBoxTotalLabour";
            this.textBoxTotalLabour.Size = new System.Drawing.Size(82, 20);
            this.textBoxTotalLabour.TabIndex = 44;
            // 
            // buttonPrint
            // 
            this.buttonPrint.BackColor = System.Drawing.Color.LightYellow;
            this.buttonPrint.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonPrint.Location = new System.Drawing.Point(496, 618);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new System.Drawing.Size(100, 32);
            this.buttonPrint.TabIndex = 48;
            this.buttonPrint.Text = "Print";
            this.buttonPrint.UseVisualStyleBackColor = false;
            this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
            // 
            // buttonSaveInvoice
            // 
            this.buttonSaveInvoice.BackColor = System.Drawing.Color.LightYellow;
            this.buttonSaveInvoice.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonSaveInvoice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonSaveInvoice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonSaveInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonSaveInvoice.Location = new System.Drawing.Point(368, 618);
            this.buttonSaveInvoice.Name = "buttonSaveInvoice";
            this.buttonSaveInvoice.Size = new System.Drawing.Size(100, 32);
            this.buttonSaveInvoice.TabIndex = 45;
            this.buttonSaveInvoice.Text = "Save Invoice";
            this.buttonSaveInvoice.UseVisualStyleBackColor = false;
            this.buttonSaveInvoice.Click += new System.EventHandler(this.buttonSaveInvoice_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.LightYellow;
            this.buttonCancel.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonCancel.Location = new System.Drawing.Point(623, 618);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(100, 32);
            this.buttonCancel.TabIndex = 46;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonExportToExcel
            // 
            this.buttonExportToExcel.BackColor = System.Drawing.Color.LightYellow;
            this.buttonExportToExcel.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonExportToExcel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.buttonExportToExcel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.buttonExportToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportToExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.buttonExportToExcel.Location = new System.Drawing.Point(867, 618);
            this.buttonExportToExcel.Name = "buttonExportToExcel";
            this.buttonExportToExcel.Size = new System.Drawing.Size(161, 32);
            this.buttonExportToExcel.TabIndex = 49;
            this.buttonExportToExcel.Text = "Export To Excel";
            this.buttonExportToExcel.UseVisualStyleBackColor = false;
            this.buttonExportToExcel.Click += new System.EventHandler(this.buttonExportToExcel_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(1030, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 31);
            this.button1.TabIndex = 51;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(33, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 31);
            this.label1.TabIndex = 50;
            this.label1.Text = "Customer Invoices  :- ";
            // 
            // Invoices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1190, 676);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonExportToExcel);
            this.Controls.Add(this.buttonPrint);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSaveInvoice);
            this.Controls.Add(this.textBoxTotalLabour);
            this.Controls.Add(this.textBoxTotalFine);
            this.Controls.Add(this.labelDummy2);
            this.Controls.Add(this.textBoxTotalNetWeight);
            this.Controls.Add(this.labelDummy1);
            this.Controls.Add(this.textBoxTotalGrossWeight);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.invoiceDateTimePicker);
            this.Controls.Add(this.buttonDeleteSelected);
            this.Controls.Add(this.buttonUpdateItem);
            this.Controls.Add(this.clearEntryButton);
            this.Controls.Add(this.buttonAddNewCustomer);
            this.Controls.Add(this.groupBoxItemEntryMode);
            this.Controls.Add(this.selectCustomerLabel);
            this.Controls.Add(this.selectCustomerComboBox);
            this.Controls.Add(this.buttonAddItem);
            this.Controls.Add(this.groupBoxNewItem);
            this.Controls.Add(this.billDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Invoices";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Create New Invoice";
            this.Load += new System.EventHandler(this.Invoices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.billBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            this.groupBoxNewItem.ResumeLayout(false);
            this.groupBoxNewItem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSoldBindingSource)).EndInit();
            this.groupBoxItemEntryMode.ResumeLayout(false);
            this.groupBoxItemEntryMode.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource billBindingSource;
        private BillingDBDataSet billingDBDataSet;
        private BillingDBDataSetTableAdapters.BillTableAdapter billTableAdapter;
        private BillingDBDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView billDataGridView;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private BillingDBDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.TextBox itemCodeTextBox;
        private System.Windows.Forms.TextBox pcsTextBox;
        private System.Windows.Forms.TextBox grossWeightTextBox;
        private System.Windows.Forms.TextBox wtChkTextBox;
        private System.Windows.Forms.TextBox netWeightTextBox;
        private System.Windows.Forms.TextBox hishobTextBox;
        private System.Windows.Forms.TextBox tunchTextBox;
        private System.Windows.Forms.TextBox labourRateTextBox;
        private System.Windows.Forms.TextBox fineTextBox;
        private System.Windows.Forms.TextBox labourTextBox;
        private System.Windows.Forms.GroupBox groupBoxNewItem;
        private System.Windows.Forms.Button buttonAddItem;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private BillingDBDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.BindingSource invoicesBindingSource;
        private BillingDBDataSetTableAdapters.InvoicesTableAdapter invoicesTableAdapter;
        private System.Windows.Forms.BindingSource itemsSoldBindingSource;
        private BillingDBDataSetTableAdapters.ItemsSoldTableAdapter itemsSoldTableAdapter;
        private System.Windows.Forms.ComboBox selectCustomerComboBox;
        private System.Windows.Forms.Label selectCustomerLabel;
        private System.Windows.Forms.GroupBox groupBoxItemEntryMode;
        private System.Windows.Forms.RadioButton radioButtonRegular;
        private System.Windows.Forms.RadioButton radioButtonPerKg;
        private System.Windows.Forms.RadioButton radioButtonPerPcs;
        private System.Windows.Forms.Button buttonNewItem;
        private System.Windows.Forms.Button buttonAddNewCustomer;
        private System.Windows.Forms.ComboBox selectItemsComboBox;
        private System.Windows.Forms.Button clearEntryButton;
        private System.Windows.Forms.Button buttonUpdateItem;
        private System.Windows.Forms.Button buttonDeleteSelected;
        private System.Windows.Forms.DateTimePicker invoiceDateTimePicker;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox textBoxTotalGrossWeight;
        private System.Windows.Forms.Label labelDummy1;
        private System.Windows.Forms.TextBox textBoxTotalNetWeight;
        private System.Windows.Forms.Label labelDummy2;
        private System.Windows.Forms.TextBox textBoxTotalFine;
        private System.Windows.Forms.TextBox textBoxTotalLabour;
        private System.Windows.Forms.Button buttonPrint;
        private System.Windows.Forms.Button buttonSaveInvoice;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonExportToExcel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}